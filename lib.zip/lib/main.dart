import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/auth_gate.dart';
import 'theme/app_theme.dart';

// TODO: these are your project's public URL + anon key (Settings -> API).
// Safe to keep in source — the anon key is meant to be public; every real
// permission check happens server-side via Row Level Security.
const supabaseUrl = 'https://dqdvyglozwlxucsxiwdt.supabase.co';
const supabaseAnonKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRxZHZ5Z2xvendseHVjc3hpd2R0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM0MzAxNTMsImV4cCI6MjA5OTAwNjE1M30.LwQhrHM05wwrbkyjtrFayMsUYRch38P85dH_SzyFv_0';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: supabaseUrl,
    anonKey: supabaseAnonKey,
  );

  runApp(const SplitEasyApp());
}

class SplitEasyApp extends StatelessWidget {
  const SplitEasyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SplitEasy',
      theme: AppTheme.theme,
      home: const AuthGate(),
    );
  }
}
