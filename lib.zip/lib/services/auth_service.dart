import 'package:supabase_flutter/supabase_flutter.dart';
import 'supabase_client.dart';

class AuthService {
  /// Registers a new user. The `handle_new_user` trigger in schema.sql
  /// auto-creates the matching `profiles` row from `data.name` / email.
  Future<AuthResponse> signUp({
    required String email,
    required String password,
    required String name,
  }) {
    return supabase.auth.signUp(
      email: email,
      password: password,
      data: {'name': name},
    );
  }

  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) {
    return supabase.auth.signInWithPassword(email: email, password: password);
  }

  Future<void> signOut() {
    return supabase.auth.signOut();
  }

  User? get currentUser => supabase.auth.currentUser;

  /// Emits whenever auth state changes (sign in, sign out, token refresh).
  /// Use this to drive an AuthGate widget.
  Stream<AuthState> get authStateChanges => supabase.auth.onAuthStateChange;
}
