import '../models/models.dart';
import 'supabase_client.dart';

class GroupService {
  /// Creates a group and adds the current user as its first member.
  Future<AppGroup> createGroup({
    required String name,
    required String currency,
  }) async {
    final uid = supabase.auth.currentUser!.id;

    final groupRow = await supabase
        .from('groups')
        .insert({
          'name': name,
          'currency': currency,
          'created_by': uid,
        })
        .select()
        .single();

    await supabase.from('group_members').insert({
      'group_id': groupRow['id'],
      'user_id': uid,
    });

    return AppGroup.fromMap(groupRow);
  }

  /// Lists every group the current user belongs to.
  /// RLS ensures this only ever returns groups they're actually a member of.
  Future<List<AppGroup>> getMyGroups() async {
    final uid = supabase.auth.currentUser!.id;

    final rows = await supabase
        .from('group_members')
        .select('groups(*)')
        .eq('user_id', uid);

    return (rows as List)
        .map((row) => AppGroup.fromMap(row['groups'] as Map<String, dynamic>))
        .toList();
  }

  /// Fetches a single group's details.
  Future<AppGroup> getGroup(String groupId) async {
    final row =
        await supabase.from('groups').select().eq('id', groupId).single();
    return AppGroup.fromMap(row);
  }

  /// Lists members of a group along with their profile info (name/email).
  Future<List<GroupMemberInfo>> getGroupMembers(String groupId) async {
    final rows = await supabase
        .from('group_members')
        .select('user_id, profiles(name, email)')
        .eq('group_id', groupId);

    return (rows as List)
        .map((row) => GroupMemberInfo.fromMap(row as Map<String, dynamic>))
        .toList();
  }

  /// Looks up a user by email so they can be invited to a group.
  /// Returns null if no profile matches (they need to register first).
  Future<Profile?> findUserByEmail(String email) async {
    final row = await supabase
        .from('profiles')
        .select()
        .eq('email', email)
        .maybeSingle();

    if (row == null) return null;
    return Profile.fromMap(row);
  }

  /// Adds an existing user (by id) to a group.
  Future<void> addMember({required String groupId, required String userId}) {
    return supabase.from('group_members').insert({
      'group_id': groupId,
      'user_id': userId,
    });
  }

  Future<void> removeMember({
    required String groupId,
    required String userId,
  }) {
    return supabase
        .from('group_members')
        .delete()
        .eq('group_id', groupId)
        .eq('user_id', userId);
  }
}
