import '../models/models.dart';
import 'supabase_client.dart';

class ExpenseService {
  /// Adds an expense and its resolved per-participant splits in one call.
  ///
  /// [splits] must already be resolved to dollar amounts client-side —
  /// for EQUAL that's amount / participants.length, for EXACT it's whatever
  /// the user typed, for PERCENTAGE/SHARES it's the computed dollar value.
  /// The sum of split amounts should equal [amount] (the UI should enforce
  /// this before calling here).
  Future<AppExpense> addExpense({
    required String groupId,
    required String description,
    required String category,
    required double amount,
    required String paidBy,
    required SplitType splitType,
    required List<ExpenseSplitInput> splits,
  }) async {
    final uid = supabase.auth.currentUser!.id;

    final expenseRow = await supabase
        .from('expenses')
        .insert({
          'group_id': groupId,
          'description': description,
          'category': category,
          'amount': amount,
          'paid_by': paidBy,
          'split_type': splitType.dbValue,
          'created_by': uid,
        })
        .select()
        .single();

    final expenseId = expenseRow['id'] as String;

    await supabase
        .from('expense_splits')
        .insert(splits.map((s) => s.toInsertMap(expenseId)).toList());

    return AppExpense.fromMap(expenseRow);
  }

  /// Lists expenses for a group, most recent first.
  Future<List<AppExpense>> getExpenses(String groupId, {String? category}) async {
    var query = supabase.from('expenses').select().eq('group_id', groupId);

    if (category != null) {
      query = query.eq('category', category);
    }

    final rows = await query.order('created_at', ascending: false);
    return (rows as List)
        .map((row) => AppExpense.fromMap(row as Map<String, dynamic>))
        .toList();
  }

  /// Gets the per-participant splits for a single expense.
  Future<List<ExpenseSplitInput>> getSplitsForExpense(String expenseId) async {
    final rows = await supabase
        .from('expense_splits')
        .select()
        .eq('expense_id', expenseId);

    return (rows as List)
        .map((row) => ExpenseSplitInput(
              userId: row['user_id'] as String,
              amountOwed: (row['amount_owed'] as num).toDouble(),
            ))
        .toList();
  }

  /// Deletes an expense. RLS only allows the original creator to do this;
  /// `on delete cascade` on expense_splits removes its splits automatically.
  Future<void> deleteExpense(String expenseId) {
    return supabase.from('expenses').delete().eq('id', expenseId);
  }
}
