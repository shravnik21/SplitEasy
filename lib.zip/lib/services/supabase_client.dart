import 'package:supabase_flutter/supabase_flutter.dart';

/// Single shared accessor for the Supabase client.
/// Import this instead of calling Supabase.instance.client everywhere.
final supabase = Supabase.instance.client;
