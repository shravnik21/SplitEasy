import '../models/models.dart';
import 'supabase_client.dart';

class SettlementService {
  /// Records a settlement — e.g. "I paid Alex $20" — which updates net
  /// balances without being treated as an expense.
  Future<Settlement> recordSettlement({
    required String groupId,
    required String paidTo,
    required double amount,
  }) async {
    final uid = supabase.auth.currentUser!.id;

    final row = await supabase
        .from('settlements')
        .insert({
          'group_id': groupId,
          'paid_by': uid,
          'paid_to': paidTo,
          'amount': amount,
        })
        .select()
        .single();

    return Settlement.fromMap(row);
  }

  Future<List<Settlement>> getSettlements(String groupId) async {
    final rows = await supabase
        .from('settlements')
        .select()
        .eq('group_id', groupId)
        .order('created_at', ascending: false);

    return (rows as List)
        .map((row) => Settlement.fromMap(row as Map<String, dynamic>))
        .toList();
  }
}
